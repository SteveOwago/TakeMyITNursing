<?php echo e($slot); ?>

<?php /**PATH /home/takemyit/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>